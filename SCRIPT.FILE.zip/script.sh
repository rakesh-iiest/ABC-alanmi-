#!/bin/bash


directory="./benchmark"

#bash check if the directory exists

if [ -d $directory ]; then
	echo "directory exists..."
else
	echo "directory does not exists"
fi


#Listing all the benchmark file
for f in $( ls ./benchmark/ ); do
	echo $f
done

start_time=$(date +%s)

#echo "uid is ${UID}"
#echo "uname is ${USER}"
#echo "FILE LIST "
#echo `ls -l` 							


# commands executes for each file 		
for f in $( ls ./benchmark/ ); do
	echo `gnome-terminal -e ./abc`
	echo `read_blif $f`
	echo `strash` 	
	echo `write_verilog $f.v`
	echo `quit`
done


end_time=$(date +%s) 
diffTime=$(( $end_time - $start_time ))

echo "It took $diffTime seconds"
