extern int Abc_RealMain(int argc, char *argv[]);

int main(int argc, char *argv[])
{
   return Abc_RealMain(argc, argv);
}
